function SudokuGenerate() {
  var table = document.getElementById("grid");

  var rowLength = 9;
  let counter = 0;
  let totalhtml = ""

  for (var i = 0; i < rowLength; i ++) {
    let htmlBlah = `<tr class ="row">
      <td id =${counter} class ="cell"><input type="text" maxlength="1"/></td>
      <td id =${counter + 1} class ="cell"><input type="text" maxlength="1"/></td>
      <td id =${counter + 2} class ="cell"><input type="text" maxlength="1"/></td>
      <td id =${counter + 3} class ="cell"><input type="text" maxlength="1"/></td>
      <td id =${counter + 4} class ="cell"><input type="text" maxlength="1"/></td>
      <td id =${counter + 5} class ="cell"><input type="text" maxlength="1"/></td>
      <td id =${counter + 6} class ="cell"><input type="text" maxlength="1"/></td>
      <td id =${counter + 7} class ="cell"><input type="text" maxlength="1"/></td>
      <td id =${counter + 8} class ="cell"><input type="text" maxlength="1"/></td>
        </tr>`
    var row = table.rows[i];
    counter += rowLength;
    totalhtml += htmlBlah;
  }

  table.innerHTML = totalhtml;
}

async function NaharLover(){
  await fetch("http://127.0.0.1:5000/logic", {
    method: "GET",
    headers: {Accept:"application/json","Content-Type":"application/json"}

  }).then(res => console.log(res.json()))
}

NaharLover();
